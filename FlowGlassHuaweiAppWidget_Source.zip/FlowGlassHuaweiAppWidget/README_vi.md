# Flow Glass Huawei — Android AppWidget (bản mã nguồn thử nghiệm)

Dự án chuyển phần giao diện đồng hồ 2×4 của Flow Glass Widget VN Stable sang Android AppWidget độc lập, hướng tới Huawei Pura 80 Pro chạy EMUI 15.0.0 và launcher Huawei mặc định.

## Đã đưa vào dự án

- Đồng hồ hệ thống 12/24 giờ bằng `TextClock`.
- Ngày dương và lịch âm Việt Nam, thuật toán thiên văn múi giờ UTC+7.
- Hàng lịch 7 ngày, bắt đầu từ thứ Hai; ngày hiện tại được làm nổi bật.
- Thời tiết hiện tại và nhiệt độ cao/thấp trong ngày qua Open-Meteo; dùng vị trí gần nhất, hoặc lấy một lần khi người dùng mở ứng dụng và cho phép vị trí.
- Các biểu tượng thời tiết gốc được trích từ gói Stable.
- Hai bố cục: kích thước tối thiểu tương đương 2×4 và bố cục rộng khi launcher cấp đủ chiều rộng.
- Nền kính bán trong suốt, viền sáng và chuyển mờ biểu tượng thời tiết nhẹ mỗi 24 giây.
- Toàn bộ 326 tài nguyên gốc cùng `manifest.xml` được giữ trong `app/src/main/assets/flowglass_reference/` để đối chiếu khi tinh chỉnh.

## Những gì chưa thể giữ nguyên từ MTZ

MTZ gốc phụ thuộc các `ContentProvider` riêng của Xiaomi/MIUI cho thời tiết, cài đặt, thiết bị và một số binder khác. Bản Huawei không gọi các provider đó. Thời tiết được thay bằng Open-Meteo; lịch âm được tính trong ứng dụng.

Nền kính ở bản này là lớp gradient bán trong suốt có viền, không phải blur thật của phần hình nền nằm phía sau widget. Android AppWidget và launcher Huawei không cung cấp API công khai, dùng chung trên mọi máy, để widget lấy đúng vùng wallpaper phía sau vị trí widget rồi blur trực tiếp. Không nên quảng cáo đây là blur wallpaper động.

## Mở và build

Yêu cầu môi trường build:

- Android Studio hoặc AndroidIDE có hỗ trợ Android Gradle Plugin 8.7.3.
- JDK 17.
- Gradle 8.9.
- Android SDK Platform 35 và Build Tools tương ứng.

Mở thư mục `FlowGlassHuaweiAppWidget` trong IDE, đồng bộ Gradle, sau đó chọn **Build > Build APK(s)**. Dự án chưa kèm `gradlew`/`gradle-wrapper.jar`; IDE cần dùng hoặc tải Gradle 8.9. Sau khi build, cài APK lên Huawei, mở ứng dụng, cấp quyền vị trí, nhấn **Cập nhật thời tiết**, rồi thêm widget từ màn hình chính.

## Kiểm tra trong lần chuẩn bị này

- Đã khôi phục đúng file `Flow_Glass_Widget_VN_HyperOS4_China_Stable.mtz` từ thư viện và giải nén được cấu trúc bên trong.
- Đã xác nhận gói MTZ có `clock_2x4` và `description.xml`; gói con có 326 tệp tài nguyên.
- Đã xác nhận biến `zmszmh_kg` trong manifest Stable là `1`; giữ nguyên manifest gốc trong thư mục tham chiếu.
- Đã kiểm tra 15 tệp XML của dự án ở mức well-formed.
- Đã chạy kiểm thử lịch âm UTC+7 với các ngày Tết 2024, 2025, Rằm tháng Tám 2024 và các tháng nhuận 2020, 2023; các ca kiểm thử đều qua.

## Trạng thái build và kiểm thử thiết bị

**Đây là mã nguồn dự án, chưa phải APK.** Môi trường hiện tại có Java 21 nhưng không có Android SDK, Gradle hoặc Android Build Tools, nên chưa thể chạy Gradle build, kiểm tra APK bằng `aapt`/`apksigner`, cài đặt hay thử thực tế trên Huawei Pura 80 Pro/EMUI 15. Không được coi bản này là Stable hoặc đã xác nhận tương thích thiết bị cho đến khi build và thử trên máy thật.

Các điểm cần kiểm tra sau khi build: quyền vị trí trên EMUI 15, khả năng nhận cập nhật nền theo chính sách pin của Huawei, cách launcher bố trí hai kích thước widget, hiệu ứng ViewFlipper và kết quả thời tiết qua mạng.
