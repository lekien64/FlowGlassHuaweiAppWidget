package com.flowglass.huawei;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQUEST_LOCATION = 41;
    private TextView status;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        Button location = findViewById(R.id.btn_location);
        Button refresh = findViewById(R.id.btn_refresh);
        location.setOnClickListener(v -> requestLocation());
        refresh.setOnClickListener(v -> refreshWeather());
        showStatus();
    }

    private void requestLocation() {
        if (hasLocationPermission()) {
            refreshWeather();
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        }
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void refreshWeather() {
        if (!hasLocationPermission()) {
            status.setText("Bạn cần cho phép vị trí để lấy thời tiết tự động.");
            return;
        }
        status.setText("Đang lấy vị trí và cập nhật thời tiết…");
        WeatherRepository.refresh(this, true, () -> runOnUiThread(() -> {
            WidgetRenderer.updateAll(this);
            WeatherRepository.Weather weather = WeatherRepository.read(this);
            status.setText("Đã cập nhật: " + weather.temperature + " · " + weather.summary
                    + (weather.range.isEmpty() ? "" : " · " + weather.range));
        }));
    }

    private void showStatus() {
        if (hasLocationPermission()) {
            WeatherRepository.Weather weather = WeatherRepository.read(this);
            status.setText(weather.updatedAt > 0
                    ? "Thời tiết gần nhất: " + weather.temperature + " · " + weather.summary
                    : "Đã có quyền vị trí. Nhấn Cập nhật thời tiết để lấy dữ liệu đầu tiên.");
        } else {
            status.setText("Để lấy thời tiết tự động, hãy cấp quyền vị trí rồi cập nhật.");
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_LOCATION) {
            if (hasLocationPermission()) refreshWeather();
            else status.setText("Chưa được cấp quyền vị trí. Bạn vẫn có thể dùng đồng hồ và lịch âm.");
        }
    }
}
