package com.flowglass.huawei;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.RemoteViews;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

final class WidgetRenderer {
    private static final Locale VI = Locale.forLanguageTag("vi-VN");
    private static final String[] WEEK_LABELS = {"T2", "T3", "T4", "T5", "T6", "T7", "CN"};
    private WidgetRenderer() {}

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, FlowGlassWidgetProvider.class));
        for (int id : ids) updateOne(context, manager, id);
    }

    static void updateOne(Context context, AppWidgetManager manager, int appWidgetId) {
        Bundle options = manager.getAppWidgetOptions(appWidgetId);
        int width = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH,
                options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250));
        boolean wide = width >= 340;
        RemoteViews views = new RemoteViews(context.getPackageName(),
                wide ? R.layout.widget_flow_glass_wide : R.layout.widget_flow_glass);

        LocalDate today = LocalDate.now();
        String solar = today.format(DateTimeFormatter.ofPattern("EEEE, d 'tháng' M", VI));
        solar = solar.substring(0, 1).toUpperCase(VI) + solar.substring(1);
        VietnameseLunarCalendar.LunarDate lunar = VietnameseLunarCalendar.fromSolar(today);
        String lunarText = "Âm lịch: " + lunar.day + " tháng " + lunar.month + (lunar.leapMonth ? " nhuận" : "");
        views.setTextViewText(R.id.solar_date, solar);
        views.setTextViewText(R.id.lunar_date, lunarText);

        LocalDate monday = today.with(DayOfWeek.MONDAY);
        for (int i = 0; i < 7; i++) {
            LocalDate date = monday.plusDays(i);
            int weekdayId = context.getResources().getIdentifier("weekday_" + i, "id", context.getPackageName());
            int dayId = context.getResources().getIdentifier("daynum_" + i, "id", context.getPackageName());
            int cellId = context.getResources().getIdentifier("cell_" + i, "id", context.getPackageName());
            views.setTextViewText(weekdayId, WEEK_LABELS[i]);
            views.setTextViewText(dayId, String.valueOf(date.getDayOfMonth()));
            views.setInt(cellId, "setBackgroundResource",
                    date.equals(today) ? R.drawable.day_today : R.drawable.day_normal);
        }

        WeatherRepository.Weather weather = WeatherRepository.read(context);
        views.setTextViewText(R.id.weather_temp, weather.temperature);
        String details = weather.summary;
        if (!weather.range.isEmpty()) details += " · " + weather.range;
        views.setTextViewText(R.id.weather_summary, details);
        views.setImageViewResource(R.id.weather_icon_a, WeatherRepository.iconResource(weather));
        views.setImageViewResource(R.id.weather_icon_b, WeatherRepository.iconResource(weather));

        Intent open = new Intent(context, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(context, appWidgetId, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, openPending);
        Intent refresh = new Intent(context, FlowGlassWidgetProvider.class);
        refresh.setAction(FlowGlassWidgetProvider.ACTION_REFRESH);
        PendingIntent refreshPending = PendingIntent.getBroadcast(context, appWidgetId + 10000, refresh,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.weather_icon, refreshPending);
        views.setOnClickPendingIntent(R.id.weather_summary, refreshPending);
        manager.updateAppWidget(appWidgetId, views);
    }
}
