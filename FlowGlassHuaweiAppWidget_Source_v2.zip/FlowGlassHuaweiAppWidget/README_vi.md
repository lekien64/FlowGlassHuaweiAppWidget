# Flow Glass Huawei — Android AppWidget (bản mã nguồn thử nghiệm)

Dự án chuyển phần giao diện đồng hồ 2×4 của Flow Glass Widget VN Stable sang Android AppWidget độc lập, hướng tới Huawei Pura 80 Pro chạy EMUI 15.0.0 và launcher Huawei mặc định.

## Đã đưa vào dự án

- Đồng hồ hệ thống 12/24 giờ bằng `TextClock`.
- Ngày dương và lịch âm Việt Nam, thuật toán thiên văn múi giờ UTC+7.
- Hàng lịch 7 ngày, bắt đầu từ thứ Hai; ngày hiện tại được làm nổi bật.
- Thời tiết hiện tại và nhiệt độ cao/thấp trong ngày qua Open-Meteo; dùng vị trí gần nhất, hoặc lấy một lần khi người dùng mở ứng dụng và cho phép vị trí.
- Các biểu tượng thời tiết gốc được trích từ gói Stable.
- Hai bố cục: kích thước tối thiểu tương đương 2×4 và bố cục rộng khi launcher cấp đủ chiều rộng.
- Nền kính bán trong suốt, viền sáng và chuyển mờ biểu tượng thời tiết nhẹ mỗi 24 giây.
- Toàn bộ 326 tài nguyên gốc cùng `manifest.xml` được giữ trong `app/src/main/assets/flowglass_reference/` để đối chiếu khi tinh chỉnh.

## Những gì chưa thể giữ nguyên từ MTZ

MTZ gốc phụ thuộc các `ContentProvider` riêng của Xiaomi/MIUI cho thời tiết, cài đặt, thiết bị và một số binder khác. Bản Huawei không gọi các provider đó. Thời tiết được thay bằng Open-Meteo; lịch âm được tính trong ứng dụng.

Nền kính ở bản này là lớp gradient bán trong suốt có viền, không phải blur thật của phần hình nền nằm phía sau widget. Android AppWidget và launcher Huawei không cung cấp API công khai, dùng chung trên mọi máy, để widget lấy đúng vùng wallpaper phía sau vị trí widget rồi blur trực tiếp. Không nên quảng cáo đây là blur wallpaper động.

## Mở và build

Yêu cầu môi trường build:

- Android Studio hoặc AndroidIDE có hỗ trợ Android Gradle Plugin 8.7.3.
- JDK 17.
- Gradle 8.9.
- Android SDK Platform 35 và Build Tools tương ứng.

Mở thư mục `FlowGlassHuaweiAppWidget` trong IDE, đồng bộ Gradle, sau đó chọn **Build > Build APK(s)**. Dự án chưa kèm `gradlew`/`gradle-wrapper.jar`; IDE cần dùng hoặc tải Gradle 8.9. Sau khi build, cài APK lên Huawei, mở ứng dụng, cấp quyền vị trí, nhấn **Cập nhật thời tiết**, rồi thêm widget từ màn hình chính.

## Kiểm tra trong lần chuẩn bị này

- Đã khôi phục đúng file `Flow_Glass_Widget_VN_HyperOS4_China_Stable.mtz` từ thư viện và giải nén được cấu trúc bên trong.
- Đã xác nhận gói MTZ có `clock_2x4` và `description.xml`; gói con có 326 tệp tài nguyên.
- Đã xác nhận biến `zmszmh_kg` trong manifest Stable là `1`; giữ nguyên manifest gốc trong thư mục tham chiếu.
- Đã kiểm tra 15 tệp XML của dự án ở mức well-formed.
- Đã chạy kiểm thử lịch âm UTC+7 với các ngày Tết 2024, 2025, Rằm tháng Tám 2024 và các tháng nhuận 2020, 2023; các ca kiểm thử đều qua.

## Trạng thái build và kiểm thử thiết bị

**Đây là mã nguồn dự án, chưa phải APK.** Môi trường hiện tại có Java 21 nhưng không có Android SDK, Gradle hoặc Android Build Tools, nên chưa thể chạy Gradle build, kiểm tra APK bằng `aapt`/`apksigner`, cài đặt hay thử thực tế trên Huawei Pura 80 Pro/EMUI 15. Không được coi bản này là Stable hoặc đã xác nhận tương thích thiết bị cho đến khi build và thử trên máy thật.

Các điểm cần kiểm tra sau khi build: quyền vị trí trên EMUI 15, khả năng nhận cập nhật nền theo chính sách pin của Huawei, cách launcher bố trí hai kích thước widget, hiệu ứng ViewFlipper và kết quả thời tiết qua mạng.


## Bản cập nhật 0.2.0-preview

- Dùng múi giờ Việt Nam (`Asia/Ho_Chi_Minh`) nhất quán cho ngày dương và lịch âm.
- Dải tuần hiển thị ngày dương lớn và ngày âm nhỏ bên dưới.
- Khi mở ứng dụng, tự làm mới thời tiết nếu quyền vị trí đã được cấp.
- Tạo lớp kính mờ mô phỏng từ ảnh nền hiện tại đã thu nhỏ/làm mờ; làm mới khi hệ thống phát thông báo đổi hình nền.
- Chạm đồng hồ mở màn hình báo thức; chạm vùng thời tiết mở ứng dụng thời tiết nếu launcher/ROM cung cấp; chạm ngày và dải lịch mở ứng dụng lịch. Nếu không tìm thấy ứng dụng đích, thao tác dự phòng mở Flow Glass.

**Giới hạn cần biết:** ảnh nền làm mờ là ảnh chụp mẫu của wallpaper, không phải hiệu ứng blur trực tiếp theo đúng từng pixel phía sau widget. Quyền truy cập wallpaper có thể bị ROM/launcher hạn chế; khi không đọc được, widget vẫn hiển thị nền kính tối bán trong suốt. Việc mở đúng ứng dụng thời tiết/lịch phụ thuộc các ứng dụng trên máy có đăng ký Android app category tương ứng hay không.


## Cập nhật 0.4.0 – Flow Glass layout refinement

- Bỏ hoạt ảnh lặp của biểu tượng thời tiết và lớp sheen chạy liên tục.
- Chỉ giữ hoạt ảnh xuất hiện một lần theo hướng đồng hồ từ tâm ra trái và biểu tượng thời tiết từ tâm ra phải (layout animation khi widget được dựng).
- Tăng cỡ và độ đậm đồng hồ; tăng kích thước biểu tượng thời tiết.
- Tô cam số ngày hiện tại và tăng độ rõ của lớp kính lịch tuần.
- Vùng thời tiết ưu tiên mở ứng dụng Huawei Weather qua package launch intent; không chuyển hướng về Flow Glass nếu không tìm thấy ứng dụng thời tiết.
- Vùng trống của widget không được gán hành động.

Lưu ý: hành vi hoạt ảnh khi widget được thêm/cập nhật phụ thuộc launcher/EMUI; cần kiểm thử trên thiết bị thật.


## Cập nhật v0.5.0 – ưu tiên hiển thị đủ lịch trên 2×4

- Gộp ngày dương và âm thành một dòng: `Thứ 5, 5/11 - Âl: 27/9`.
- Ẩn dòng âm lịch riêng để dành chiều cao cho lịch tuần ở kích thước 2×4.
- Tối ưu chiều cao đồng hồ, icon thời tiết, khoảng đệm và hàng lịch; mỗi ngày trong tuần vẫn có thứ, ngày dương và ngày âm.
- Áp dụng định dạng ngày giống nhau cho 2×4 và 3×4.
- Làm viền bo tròn mềm hơn, nền lịch tuần tối và mờ hơn, ô ngày hiện tại có kính màu hổ phách đậm hơn.

Lưu ý: cần build bằng GitHub Actions và xác nhận trực tiếp trên launcher Huawei; việc hiển thị còn phụ thuộc kích thước dp thực tế mà launcher cấp cho widget.


## Cập nhật v0.7.0 – chạm không mở ứng dụng, ghim widget và ghi công tác giả

- Mọi vùng chạm của widget được gán tới một BroadcastReceiver rỗng (no-op) để thay thế PendingIntent cũ mà launcher có thể còn lưu từ các bản trước. Không vùng nào mở Flow Glass hoặc ứng dụng khác.
- Thêm nút **Đưa widget ra màn hình chính** trong ứng dụng. Trên Android/launcher hỗ trợ `requestPinAppWidget`, hệ thống sẽ hiện yêu cầu xác nhận ghim widget; nếu launcher Huawei không hỗ trợ, ứng dụng hướng dẫn thêm thủ công qua Widget. Việc ghim luôn cần xác nhận của người dùng.
- Thêm dòng **Mod by Le Kien** và nút theo dõi/ủng hộ tác giả mở `https://www.tiktok.com/@xiaomi.studio1`.
- Bỏ nền kính bị vẽ lặp ở LinearLayout con, giữ một lớp nền và outline ở FrameLayout gốc để tránh viền kép tại bốn góc.

Lưu ý: do launcher Huawei có thể lưu trạng thái click của widget cũ, sau khi cài bản mới nên xóa widget cũ khỏi màn hình chính rồi thêm lại một lần. Bản APK vẫn cần được build bằng GitHub Actions và kiểm tra trên thiết bị thật.


## Bản thử nghiệm widget một kích thước 2x4

Bản 0.9.0 dùng duy nhất layout `widget_flow_glass`, bỏ nhánh tự chuyển sang layout rộng theo kích thước launcher và tắt khả năng resize trong metadata. Kích thước tối thiểu/resize được cố định ở 250dp x 140dp để thử nghiệm lỗi launcher Xiaomi khi widget đa kích thước. Đây là thử nghiệm tương thích; số ô thực tế có thể khác nhau giữa các launcher do mật độ và lưới màn hình.
