package com.flowglass.huawei;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;

public class FlowGlassWidgetProvider extends AppWidgetProvider {
    static final String ACTION_REFRESH = "com.flowglass.huawei.ACTION_REFRESH";

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        WidgetUpdateScheduler.schedule(context);
        WidgetRenderer.updateAll(context);
        WeatherRepository.refresh(context, () -> WidgetRenderer.updateAll(context));
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_WALLPAPER_CHANGED.equals(action)) {
            // Refresh the sampled wallpaper blur without making an unnecessary weather request.
            WidgetRenderer.updateAll(context);
        } else if (ACTION_REFRESH.equals(action) || Intent.ACTION_DATE_CHANGED.equals(action)
                || Intent.ACTION_TIME_CHANGED.equals(action) || Intent.ACTION_TIMEZONE_CHANGED.equals(action)) {
            WidgetRenderer.updateAll(context);
            WeatherRepository.refresh(context, () -> WidgetRenderer.updateAll(context));
        } else if (Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            WidgetUpdateScheduler.schedule(context);
            WidgetRenderer.updateAll(context);
        }
    }
}
