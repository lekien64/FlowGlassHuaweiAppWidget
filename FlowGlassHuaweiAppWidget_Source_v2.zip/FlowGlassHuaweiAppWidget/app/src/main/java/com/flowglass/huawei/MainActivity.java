package com.flowglass.huawei;

import android.Manifest;
import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_LOCATION = 41;
    private TextView status;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        Button location = findViewById(R.id.btn_location);
        Button refresh = findViewById(R.id.btn_refresh);
        Button addWidget = findViewById(R.id.btn_add_widget);
        Button tiktok = findViewById(R.id.btn_tiktok);
        location.setOnClickListener(v -> requestLocation());
        refresh.setOnClickListener(v -> refreshWeather());
        addWidget.setOnClickListener(v -> addWidgetToHomeScreen());
        tiktok.setOnClickListener(v -> openTikTok());
        if (hasLocationPermission()) refreshWeather();
        else showStatus();
    }


    private void addWidgetToHomeScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AppWidgetManager manager = getSystemService(AppWidgetManager.class);
            ComponentName provider = new ComponentName(this, FlowGlassWidgetProvider.class);
            if (manager != null && manager.isRequestPinAppWidgetSupported()) {
                boolean requested = manager.requestPinAppWidget(provider, null, null);
                if (requested) {
                    status.setText("Đã gửi yêu cầu thêm Flow Glass. Hãy xác nhận trên màn hình chính nếu launcher hiển thị hộp thoại.");
                    return;
                }
            }
        }
        status.setText("Launcher hiện tại không hỗ trợ thêm widget trực tiếp. Hãy nhấn giữ màn hình chính → Widget → Flow Glass.");
        Toast.makeText(this, "Mở Widget từ màn hình chính để thêm Flow Glass.", Toast.LENGTH_LONG).show();
    }

    private void openTikTok() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.tiktok.com/@xiaomi.studio1"));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Không tìm thấy ứng dụng hoặc trình duyệt để mở TikTok.", Toast.LENGTH_LONG).show();
        }
    }

    private void requestLocation() {
        if (hasLocationPermission()) {
            refreshWeather();
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        }
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void refreshWeather() {
        if (!hasLocationPermission()) {
            status.setText("Bạn cần cho phép vị trí để lấy thời tiết tự động.");
            return;
        }
        status.setText("Đang lấy vị trí và cập nhật thời tiết…");
        WeatherRepository.refresh(this, true, () -> runOnUiThread(() -> {
            WidgetRenderer.updateAll(this);
            WeatherRepository.Weather weather = WeatherRepository.read(this);
            status.setText("Đã cập nhật: " + weather.temperature + " · " + weather.summary
                    + (weather.range.isEmpty() ? "" : " · " + weather.range));
        }));
    }

    private void showStatus() {
        if (hasLocationPermission()) {
            WeatherRepository.Weather weather = WeatherRepository.read(this);
            status.setText(weather.updatedAt > 0
                    ? "Thời tiết gần nhất: " + weather.temperature + " · " + weather.summary
                    : "Đã có quyền vị trí. Nhấn Cập nhật thời tiết để lấy dữ liệu đầu tiên.");
        } else {
            status.setText("Để lấy thời tiết tự động, hãy cấp quyền vị trí rồi cập nhật.");
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_LOCATION) {
            if (hasLocationPermission()) refreshWeather();
            else status.setText("Chưa được cấp quyền vị trí. Bạn vẫn có thể dùng đồng hồ và lịch âm.");
        }
    }
}
