package com.flowglass.huawei;

import java.time.LocalDate;

/** Vietnamese lunar date conversion based on the Ho Ngoc Duc astronomical algorithm (UTC+7). */
public final class VietnameseLunarCalendar {
    private static final double SYNODIC_MONTH = 29.530588853;
    private VietnameseLunarCalendar() {}

    public static final class LunarDate {
        public final int day, month, year;
        public final boolean leapMonth;
        LunarDate(int day, int month, int year, boolean leapMonth) {
            this.day = day; this.month = month; this.year = year; this.leapMonth = leapMonth;
        }
        @Override public String toString() {
            return day + " tháng " + month + (leapMonth ? " nhuận" : "") + " năm " + year;
        }
    }

    public static LunarDate fromSolar(LocalDate date) {
        return convert(date.getDayOfMonth(), date.getMonthValue(), date.getYear(), 7.0);
    }

    static LunarDate convert(int day, int month, int year, double timeZone) {
        int dayNumber = jdFromDate(day, month, year);
        int k = (int)Math.floor((dayNumber - 2415021.076998695) / SYNODIC_MONTH);
        int monthStart = getNewMoonDay(k + 1, timeZone);
        if (monthStart > dayNumber) monthStart = getNewMoonDay(k, timeZone);

        int a11 = getLunarMonth11(year, timeZone);
        int b11 = a11;
        int lunarYear;
        if (a11 >= monthStart) {
            lunarYear = year;
            a11 = getLunarMonth11(year - 1, timeZone);
        } else {
            lunarYear = year + 1;
            b11 = getLunarMonth11(year + 1, timeZone);
        }

        int lunarDay = dayNumber - monthStart + 1;
        int diff = (int)Math.floor((monthStart - a11) / 29.0);
        int lunarLeap = 0;
        int lunarMonth = diff + 11;
        if (b11 - a11 > 365) {
            int leapMonthDiff = getLeapMonthOffset(a11, timeZone);
            if (diff >= leapMonthDiff) {
                lunarMonth = diff + 10;
                if (diff == leapMonthDiff) lunarLeap = 1;
            }
        }
        if (lunarMonth > 12) lunarMonth -= 12;
        if (lunarMonth >= 11 && diff < 4) lunarYear--;
        return new LunarDate(lunarDay, lunarMonth, lunarYear, lunarLeap == 1);
    }

    private static int jdFromDate(int dd, int mm, int yy) {
        int a = (14 - mm) / 12;
        int y = yy + 4800 - a;
        int m = mm + 12 * a - 3;
        int jd = dd + (153 * m + 2) / 5 + 365 * y + y / 4 - y / 100 + y / 400 - 32045;
        if (jd < 2299161) jd = dd + (153 * m + 2) / 5 + 365 * y + y / 4 - 32083;
        return jd;
    }

    private static double newMoon(int k) {
        double t = k / 1236.85;
        double t2 = t * t;
        double t3 = t2 * t;
        double dr = Math.PI / 180.0;
        double jd1 = 2415020.75933 + 29.53058868 * k + 0.0001178 * t2 - 0.000000155 * t3;
        jd1 += 0.00033 * Math.sin((166.56 + 132.87 * t - 0.009173 * t2) * dr);
        double m = 359.2242 + 29.10535608 * k - 0.0000333 * t2 - 0.00000347 * t3;
        double mpr = 306.0253 + 385.81691806 * k + 0.0107306 * t2 + 0.00001236 * t3;
        double f = 21.2964 + 390.67050646 * k - 0.0016528 * t2 - 0.00000239 * t3;
        double c1 = (0.1734 - 0.000393 * t) * Math.sin(m * dr) + 0.0021 * Math.sin(2 * dr * m)
                - 0.4068 * Math.sin(mpr * dr) + 0.0161 * Math.sin(2 * dr * mpr)
                - 0.0004 * Math.sin(3 * dr * mpr) + 0.0104 * Math.sin(2 * dr * f)
                - 0.0051 * Math.sin(dr * (m + mpr)) - 0.0074 * Math.sin(dr * (m - mpr))
                + 0.0004 * Math.sin(dr * (2 * f + m)) - 0.0004 * Math.sin(dr * (2 * f - m))
                - 0.0006 * Math.sin(dr * (2 * f + mpr)) + 0.0010 * Math.sin(dr * (2 * f - mpr))
                + 0.0005 * Math.sin(dr * (2 * mpr + m));
        double deltaT;
        if (t < -11) {
            deltaT = 0.001 + 0.000839 * t + 0.0002261 * t2 - 0.00000845 * t3 - 0.000000081 * t * t3;
        } else {
            deltaT = -0.000278 + 0.000265 * t + 0.000262 * t2;
        }
        return jd1 + c1 - deltaT;
    }

    private static int getNewMoonDay(int k, double timeZone) {
        return (int)Math.floor(newMoon(k) + 0.5 + timeZone / 24.0);
    }

    private static double sunLongitude(double jdn) {
        double t = (jdn - 2451545.0) / 36525.0;
        double t2 = t * t;
        double dr = Math.PI / 180.0;
        double m = 357.52910 + 35999.05030 * t - 0.0001559 * t2 - 0.00000048 * t * t2;
        double l0 = 280.46645 + 36000.76983 * t + 0.0003032 * t2;
        double dl = (1.914600 - 0.004817 * t - 0.000014 * t2) * Math.sin(dr * m)
                + (0.019993 - 0.000101 * t) * Math.sin(2 * dr * m) + 0.000290 * Math.sin(3 * dr * m);
        double l = (l0 + dl) * dr;
        l = l - Math.PI * 2.0 * Math.floor(l / (Math.PI * 2.0));
        return l;
    }

    private static int getSunLongitude(int dayNumber, double timeZone) {
        return (int)Math.floor(sunLongitude(dayNumber - 0.5 - timeZone / 24.0) / Math.PI * 6.0);
    }

    private static int getLunarMonth11(int year, double timeZone) {
        int off = jdFromDate(31, 12, year) - 2415021;
        int k = (int)Math.floor(off / SYNODIC_MONTH);
        int nm = getNewMoonDay(k, timeZone);
        int sunLong = getSunLongitude(nm, timeZone);
        if (sunLong >= 9) nm = getNewMoonDay(k - 1, timeZone);
        return nm;
    }

    private static int getLeapMonthOffset(int a11, double timeZone) {
        int k = (int)Math.floor(0.5 + (a11 - 2415021.0) / SYNODIC_MONTH);
        int last = 0;
        int i = 1;
        int arc = getSunLongitude(getNewMoonDay(k + i, timeZone), timeZone);
        do {
            last = arc;
            i++;
            arc = getSunLongitude(getNewMoonDay(k + i, timeZone), timeZone);
        } while (arc != last && i < 14);
        return i - 1;
    }
}
