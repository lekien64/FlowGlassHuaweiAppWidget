package com.flowglass.huawei;

import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.widget.RemoteViews;

/** Creates a low-resolution blurred wallpaper sample behind the translucent glass panel. */
final class WallpaperGlassRenderer {
    private static final int WIDTH = 320;
    private static final int HEIGHT = 180;
    private WallpaperGlassRenderer() {}

    static void apply(Context context, RemoteViews views) {
        Bitmap blurred = create(context);
        if (blurred != null) views.setImageViewBitmap(R.id.wallpaper_blur, blurred);
    }

    private static Bitmap create(Context context) {
        try {
            Drawable wallpaper = WallpaperManager.getInstance(context).getDrawable();
            if (wallpaper == null) return null;
            Bitmap source = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(source);
            int iw = wallpaper.getIntrinsicWidth();
            int ih = wallpaper.getIntrinsicHeight();
            if (iw <= 0 || ih <= 0) { iw = WIDTH; ih = HEIGHT; }
            float scale = Math.max((float) WIDTH / iw, (float) HEIGHT / ih);
            int dw = Math.round(iw * scale);
            int dh = Math.round(ih * scale);
            wallpaper.setBounds((WIDTH - dw) / 2, (HEIGHT - dh) / 2, (WIDTH + dw) / 2, (HEIGHT + dh) / 2);
            wallpaper.draw(canvas);
            return blur(source, 18, 3);
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static Bitmap blur(Bitmap input, int radius, int passes) {
        int w = input.getWidth(), h = input.getHeight();
        int[] pixels = new int[w * h];
        input.getPixels(pixels, 0, w, 0, 0, w, h);
        int[] temp = new int[pixels.length];
        for (int pass = 0; pass < passes; pass++) {
            for (int y = 0; y < h; y++) {
                int a=0,r=0,g=0,b=0,count=0;
                for (int x = -radius; x <= radius; x++) { int c=pixels[y*w+clamp(x,0,w-1)]; a+=c>>>24; r+=(c>>16)&255; g+=(c>>8)&255; b+=c&255; count++; }
                for (int x = 0; x < w; x++) {
                    temp[y*w+x]=((a/count)<<24)|((r/count)<<16)|((g/count)<<8)|(b/count);
                    int remove=pixels[y*w+clamp(x-radius,0,w-1)];
                    int add=pixels[y*w+clamp(x+radius+1,0,w-1)];
                    a+=(add>>>24)-(remove>>>24); r+=((add>>16)&255)-((remove>>16)&255);
                    g+=((add>>8)&255)-((remove>>8)&255); b+=(add&255)-(remove&255);
                }
            }
            for (int x = 0; x < w; x++) {
                int a=0,r=0,g=0,b=0,count=0;
                for (int y = -radius; y <= radius; y++) { int c=temp[clamp(y,0,h-1)*w+x]; a+=c>>>24; r+=(c>>16)&255; g+=(c>>8)&255; b+=c&255; count++; }
                for (int y = 0; y < h; y++) {
                    pixels[y*w+x]=((a/count)<<24)|((r/count)<<16)|((g/count)<<8)|(b/count);
                    int remove=temp[clamp(y-radius,0,h-1)*w+x];
                    int add=temp[clamp(y+radius+1,0,h-1)*w+x];
                    a+=(add>>>24)-(remove>>>24); r+=((add>>16)&255)-((remove>>16)&255);
                    g+=((add>>8)&255)-((remove>>8)&255); b+=(add&255)-(remove&255);
                }
            }
        }
        Bitmap output = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        output.setPixels(pixels, 0, w, 0, 0, w, h);
        input.recycle();
        return output;
    }

    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
}
