package com.flowglass.huawei;

/** Weather symbols are intentionally static in this Flow Glass build. */
final class WeatherMotionRenderer {
    private WeatherMotionRenderer() {}
}
