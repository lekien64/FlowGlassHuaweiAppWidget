package com.flowglass.huawei;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.widget.RemoteViews;

/** Three subtle weather frames. ViewFlipper in the widget advances them without a service loop. */
final class WeatherMotionRenderer {
    private WeatherMotionRenderer() {}

    static void apply(Context context, RemoteViews views, WeatherRepository.Weather weather) {
        int resource = WeatherRepository.iconResource(weather);
        Bitmap source = BitmapFactory.decodeResource(context.getResources(), resource);
        if (source == null) return;
        views.setImageViewBitmap(R.id.weather_icon_a, frame(source, weather, 0));
        views.setImageViewBitmap(R.id.weather_icon_b, frame(source, weather, 1));
        views.setImageViewBitmap(R.id.weather_icon_c, frame(source, weather, 2));
        source.recycle();
    }

    private static Bitmap frame(Bitmap source, WeatherRepository.Weather weather, int phase) {
        int w = 192, h = 192;
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        float scale = 0.88f + (phase == 1 ? 0.025f : 0f);
        float dx = 0f, dy = 0f, rotation = 0f;
        int code = weather.code;
        if (code == 0 || code == 1 || code == 2) {
            rotation = phase == 0 ? -5f : (phase == 1 ? 0f : 5f);
            dy = phase == 1 ? -2f : 1f;
        } else if (code >= 51 && code <= 86) {
            dx = phase == 0 ? -3f : (phase == 1 ? 0f : 3f);
            dy = phase == 0 ? -1f : (phase == 1 ? 2f : -1f);
        } else {
            dx = phase == 0 ? -2f : (phase == 1 ? 2f : 0f);
        }
        canvas.translate(w / 2f + dx, h / 2f + dy);
        canvas.rotate(rotation);
        canvas.scale(scale, scale);
        paint.setAlpha(phase == 1 ? 255 : 238);
        canvas.drawBitmap(source, -source.getWidth() / 2f, -source.getHeight() / 2f, paint);
        return out;
    }
}
