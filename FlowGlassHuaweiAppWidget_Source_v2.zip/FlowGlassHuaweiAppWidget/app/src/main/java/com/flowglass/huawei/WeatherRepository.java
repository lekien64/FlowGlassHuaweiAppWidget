package com.flowglass.huawei;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class WeatherRepository {
    private static final String PREFS = "flowglass_weather";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private WeatherRepository() {}

    static final class Weather {
        final String temperature, range, summary;
        final int code, isDay;
        final long updatedAt;
        Weather(String temperature, String range, String summary, int code, int isDay, long updatedAt) {
            this.temperature = temperature; this.range = range; this.summary = summary;
            this.code = code; this.isDay = isDay; this.updatedAt = updatedAt;
        }
    }

    static Weather read(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return new Weather(p.getString("temperature", "--°"), p.getString("range", ""),
                p.getString("summary", "Chạm để cập nhật thời tiết"), p.getInt("code", -1),
                p.getInt("is_day", 1), p.getLong("updated_at", 0));
    }

    static void refresh(Context context, Runnable completion) { refresh(context, false, completion); }


    static void refresh(Context context, boolean allowActiveLocationRequest, Runnable completion) {
        Context app = context.getApplicationContext();
        if (app.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && app.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (completion != null) completion.run();
            return;
        }
        LocationManager manager = (LocationManager) app.getSystemService(Context.LOCATION_SERVICE);
        if (manager == null) { if (completion != null) completion.run(); return; }
        Location best = null;
        try {
            for (String provider : new String[]{LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER}) {
                if (manager.isProviderEnabled(provider)) {
                    Location candidate = manager.getLastKnownLocation(provider);
                    if (candidate != null && (best == null || candidate.getTime() > best.getTime())) best = candidate;
                }
            }
        } catch (Exception ignored) {}
        if (best != null && System.currentTimeMillis() - best.getTime() < 6L * 60L * 60L * 1000L) {
            fetch(app, best.getLatitude(), best.getLongitude(), completion);
            return;
        }
        if (!allowActiveLocationRequest) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putString("summary", "Mở ứng dụng để lấy vị trí")
                    .apply();
            if (completion != null) completion.run();
            return;
        }
        try {
            String provider = manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
                    ? LocationManager.NETWORK_PROVIDER : LocationManager.GPS_PROVIDER;
            manager.requestSingleUpdate(provider, new LocationListener() {
                @Override public void onLocationChanged(Location location) {
                    fetch(app, location.getLatitude(), location.getLongitude(), completion);
                }
                @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
                @Override public void onProviderEnabled(String provider) {}
                @Override public void onProviderDisabled(String provider) { if (completion != null) completion.run(); }
            }, Looper.getMainLooper());
        } catch (Exception ignored) {
            if (completion != null) completion.run();
        }
    }

    private static void fetch(Context context, double latitude, double longitude, Runnable completion) {
        EXECUTOR.execute(() -> {
            HttpURLConnection connection = null;
            try {
                String endpoint = "https://api.open-meteo.com/v1/forecast?latitude=" + latitude
                        + "&longitude=" + longitude
                        + "&current=temperature_2m,weather_code,is_day,relative_humidity_2m"
                        + "&daily=temperature_2m_max,temperature_2m_min&forecast_days=1&timezone=auto";
                connection = (HttpURLConnection) new URL(endpoint).openConnection();
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                connection.setRequestProperty("Accept", "application/json");
                try (InputStream in = connection.getInputStream();
                     BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                    StringBuilder body = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) body.append(line);
                    JSONObject root = new JSONObject(body.toString());
                    JSONObject current = root.getJSONObject("current");
                    JSONObject daily = root.getJSONObject("daily");
                    JSONArray highs = daily.getJSONArray("temperature_2m_max");
                    JSONArray lows = daily.getJSONArray("temperature_2m_min");
                    double temp = current.getDouble("temperature_2m");
                    double high = highs.getDouble(0);
                    double low = lows.getDouble(0);
                    int code = current.getInt("weather_code");
                    int isDay = current.optInt("is_day", 1);
                    String range = Math.round(low) + "°–" + Math.round(high) + "°";
                    String summary = summaryFor(code);
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                            .putString("temperature", Math.round(temp) + "°")
                            .putString("range", range)
                            .putString("summary", summary)
                            .putInt("code", code)
                            .putInt("is_day", isDay)
                            .putLong("updated_at", System.currentTimeMillis())
                            .apply();
                }
            } catch (Exception e) {
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                        .putString("summary", "Không tải được thời tiết · thử lại sau")
                        .apply();
            } finally {
                if (connection != null) connection.disconnect();
                if (completion != null) completion.run();
            }
        });
    }

    static int iconResource(Weather weather) {
        int code = weather.code;
        int icon;
        if (code == 0) icon = weather.isDay == 0 ? R.drawable.gpqw_0b : R.drawable.gpqw_0;
        else if (code <= 2) icon = weather.isDay == 0 ? R.drawable.gpqw_1b : R.drawable.gpqw_1;
        else if (code == 3) icon = R.drawable.gpqw_3;
        else if (code == 45 || code == 48) icon = R.drawable.gpqw_4;
        else if (code >= 51 && code <= 57) icon = R.drawable.gpqw_7;
        else if (code >= 61 && code <= 67) icon = R.drawable.gpqw_12;
        else if (code >= 71 && code <= 77) icon = R.drawable.gpqw_18;
        else if (code >= 80 && code <= 82) icon = R.drawable.gpqw_22;
        else if (code >= 85) icon = R.drawable.gpqw_24;
        else icon = R.drawable.gpqw_3;
        return icon;
    }

    private static String summaryFor(int code) {
        if (code == 0) return "Trời quang";
        if (code == 1) return "Ít mây";
        if (code == 2) return "Mây rải rác";
        if (code == 3) return "Nhiều mây";
        if (code == 45 || code == 48) return "Sương mù";
        if (code >= 51 && code <= 57) return "Mưa phùn";
        if (code >= 61 && code <= 67) return "Có mưa";
        if (code >= 71 && code <= 77) return "Có tuyết";
        if (code >= 80 && code <= 82) return "Mưa rào";
        if (code >= 85 && code <= 86) return "Mưa tuyết";
        if (code >= 95) return "Dông";
        return "Thời tiết hiện tại";
    }
}
