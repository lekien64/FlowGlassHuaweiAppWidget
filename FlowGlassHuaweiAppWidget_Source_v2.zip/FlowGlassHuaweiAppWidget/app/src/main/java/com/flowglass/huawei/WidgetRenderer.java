package com.flowglass.huawei;

import android.provider.AlarmClock;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.RemoteViews;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

final class WidgetRenderer {
    private static final Locale VI = Locale.forLanguageTag("vi-VN");
    private static final ZoneId VIETNAM_ZONE = ZoneId.of("Asia/Ho_Chi_Minh");
    private static final String[] WEEK_LABELS = {"T2", "T3", "T4", "T5", "T6", "T7", "CN"};
    private WidgetRenderer() {}

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, FlowGlassWidgetProvider.class));
        for (int id : ids) updateOne(context, manager, id);
    }

    static void updateOne(Context context, AppWidgetManager manager, int appWidgetId) {
        Bundle options = manager.getAppWidgetOptions(appWidgetId);
        int width = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH,
                options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250));
        boolean wide = width >= 340;
        RemoteViews views = new RemoteViews(context.getPackageName(),
                wide ? R.layout.widget_flow_glass_wide : R.layout.widget_flow_glass);

        LocalDate today = LocalDate.now(VIETNAM_ZONE);
        String solar = today.format(DateTimeFormatter.ofPattern("EEEE, d 'tháng' M", VI));
        solar = solar.substring(0, 1).toUpperCase(VI) + solar.substring(1);
        VietnameseLunarCalendar.LunarDate lunar = VietnameseLunarCalendar.fromSolar(today);
        String lunarText = "Âm lịch: " + lunar.day + " tháng " + lunar.month
                + (lunar.leapMonth ? " nhuận" : "");
        views.setTextViewText(R.id.solar_date, solar);
        views.setTextViewText(R.id.lunar_date, lunarText);

        LocalDate monday = today.with(DayOfWeek.MONDAY);
        for (int i = 0; i < 7; i++) {
            LocalDate date = monday.plusDays(i);
            VietnameseLunarCalendar.LunarDate lunarDay = VietnameseLunarCalendar.fromSolar(date);
            int weekdayId = context.getResources().getIdentifier("weekday_" + i, "id", context.getPackageName());
            int dayId = context.getResources().getIdentifier("daynum_" + i, "id", context.getPackageName());
            int lunarDayId = context.getResources().getIdentifier("lunar_daynum_" + i, "id", context.getPackageName());
            int cellId = context.getResources().getIdentifier("cell_" + i, "id", context.getPackageName());
            views.setTextViewText(weekdayId, WEEK_LABELS[i]);
            views.setTextViewText(dayId, String.valueOf(date.getDayOfMonth()));
            views.setTextViewText(lunarDayId, String.valueOf(lunarDay.day));
            views.setInt(cellId, "setBackgroundResource",
                    date.equals(today) ? R.drawable.day_today : R.drawable.day_normal);
        }

        WeatherRepository.Weather weather = WeatherRepository.read(context);
        views.setTextViewText(R.id.weather_temp, weather.temperature);
        String details = weather.summary;
        if (!weather.range.isEmpty()) details += " · " + weather.range;
        views.setTextViewText(R.id.weather_summary, details);
        views.setImageViewResource(R.id.weather_icon_a, WeatherRepository.iconResource(weather));
        views.setImageViewResource(R.id.weather_icon_b, WeatherRepository.iconResource(weather));
        WallpaperGlassRenderer.apply(context, views);

        // Background opens the companion app; individual content zones open their native apps.
        setClick(context, views, R.id.widget_root, new Intent(context, MainActivity.class), appWidgetId + 1);
        Intent alarm = new Intent(AlarmClock.ACTION_SHOW_ALARMS);
        setClickWithFallback(context, views, R.id.widget_clock, alarm, appWidgetId + 101);

        Intent weatherIntent = new Intent(Intent.ACTION_MAIN);
        weatherIntent.addCategory(Intent.CATEGORY_APP_WEATHER);
        setClickWithFallback(context, views, R.id.weather_area, weatherIntent, appWidgetId + 201);
        setClickWithFallback(context, views, R.id.weather_icon, weatherIntent, appWidgetId + 202);
        setClickWithFallback(context, views, R.id.weather_temp, weatherIntent, appWidgetId + 203);
        setClickWithFallback(context, views, R.id.weather_summary, weatherIntent, appWidgetId + 204);

        Intent calendarIntent = new Intent(Intent.ACTION_MAIN);
        calendarIntent.addCategory(Intent.CATEGORY_APP_CALENDAR);
        setClickWithFallback(context, views, R.id.solar_date, calendarIntent, appWidgetId + 301);
        setClickWithFallback(context, views, R.id.lunar_date, calendarIntent, appWidgetId + 302);
        setClickWithFallback(context, views, R.id.week_row, calendarIntent, appWidgetId + 303);

        manager.updateAppWidget(appWidgetId, views);
    }

    private static void setClickWithFallback(Context context, RemoteViews views, int viewId, Intent target, int requestCode) {
        PackageManager pm = context.getPackageManager();
        Intent resolved = target;
        if (target.resolveActivity(pm) == null) resolved = new Intent(context, MainActivity.class);
        setClick(context, views, viewId, resolved, requestCode);
    }

    private static void setClick(Context context, RemoteViews views, int viewId, Intent intent, int requestCode) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pending = PendingIntent.getActivity(context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(viewId, pending);
    }
}
