package com.flowglass.huawei;

import android.appwidget.AppWidgetManager;
import android.os.Bundle;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.app.PendingIntent;
import android.graphics.Color;
import android.widget.RemoteViews;
import android.util.TypedValue;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;

final class WidgetRenderer {
    private static final ZoneId VIETNAM_ZONE = ZoneId.of("Asia/Ho_Chi_Minh");
    private static final String[] WEEK_LABELS = {"T2", "T3", "T4", "T5", "T6", "T7", "CN"};
    private WidgetRenderer() {}

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, FlowGlassWidgetProvider.class));
        for (int id : ids) updateOne(context, manager, id);
    }

    static void updateOne(Context context, AppWidgetManager manager, int appWidgetId) {
        // One adaptive layout instance: use the launcher's actual allocated size
        // to scale typography and spacing instead of registering fragile size variants.
        Bundle options = manager.getAppWidgetOptions(appWidgetId);
        // AppWidgetOptions describes a size range, not always the currently
        // occupied rectangle. In portrait launchers (including Honor 4x6),
        // the useful estimate is minWidth x maxHeight. In landscape it is
        // maxWidth x minHeight. Using minWidth x minHeight made portrait
        // widgets calculate from the smallest possible height and shrink all
        // typography even when the visible widget was much taller.
        int minWidth = options == null ? 300 : options.getInt(
                AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 300);
        int maxWidth = options == null ? minWidth : options.getInt(
                AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, minWidth);
        int minHeight = options == null ? 150 : options.getInt(
                AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 150);
        int maxHeight = options == null ? minHeight : options.getInt(
                AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, minHeight);
        boolean portrait = context.getResources().getConfiguration().orientation
                != android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        int widthDp = portrait ? minWidth : maxWidth;
        int heightDp = portrait ? maxHeight : minHeight;
        widthDp = Math.max(160, widthDp);
        heightDp = Math.max(100, heightDp);
        RemoteViews views = new RemoteViews(context.getPackageName(),
                R.layout.widget_flow_glass);
        applyResponsiveSizing(context, views, widthDp, heightDp);

        LocalDate today = LocalDate.now(VIETNAM_ZONE);
        VietnameseLunarCalendar.LunarDate lunar = VietnameseLunarCalendar.fromSolar(today);
        // Vietnamese weekday numbering: Monday is Thứ 2, not Thứ 1.
        // Java DayOfWeek uses Monday=1 ... Sunday=7, so add one for Mon-Sat.
        String weekday = today.getDayOfWeek() == DayOfWeek.SUNDAY
                ? "CN" : "Thứ " + (today.getDayOfWeek().getValue() + 1);
        String lunarSuffix = lunar.leapMonth ? " nhuận" : "";
        String combinedDate = weekday + ", " + today.getDayOfMonth() + "/" + today.getMonthValue()
                + " - Âl: " + lunar.day + "/" + lunar.month + lunarSuffix;
        views.setTextViewText(R.id.solar_date, combinedDate);
        views.setViewVisibility(R.id.lunar_date, android.view.View.GONE);

        LocalDate monday = today.with(DayOfWeek.MONDAY);
        for (int i = 0; i < 7; i++) {
            LocalDate date = monday.plusDays(i);
            VietnameseLunarCalendar.LunarDate lunarDay = VietnameseLunarCalendar.fromSolar(date);
            int weekdayId = context.getResources().getIdentifier("weekday_" + i, "id", context.getPackageName());
            int dayId = context.getResources().getIdentifier("daynum_" + i, "id", context.getPackageName());
            int lunarDayId = context.getResources().getIdentifier("lunar_daynum_" + i, "id", context.getPackageName());
            int cellId = context.getResources().getIdentifier("cell_" + i, "id", context.getPackageName());
            views.setTextViewText(weekdayId, WEEK_LABELS[i]);
            views.setTextViewText(dayId, String.valueOf(date.getDayOfMonth()));
            views.setTextViewText(lunarDayId, String.valueOf(lunarDay.day));
            boolean isToday = date.equals(today);
            views.setInt(cellId, "setBackgroundResource",
                    isToday ? R.drawable.day_today : R.drawable.day_normal);
            views.setTextColor(dayId, isToday ? Color.rgb(255, 177, 91) : Color.WHITE);
        }

        WeatherRepository.Weather weather = WeatherRepository.read(context);
        views.setTextViewText(R.id.weather_temp, weather.temperature);
        String details = weather.summary;
        if (!weather.range.isEmpty()) details += " · " + weather.range;
        views.setTextViewText(R.id.weather_summary, details);
        // Static weather symbol: no looping weather animation.
        views.setImageViewResource(R.id.weather_icon, WeatherRepository.iconResource(weather));
        WallpaperGlassRenderer.apply(context, views);

        // Make every widget surface inert, including widgets updated in place from
        // an older release that may still retain its previous app-opening PendingIntent.
        // A harmless explicit broadcast replaces any stale click action in the launcher.
        Intent noOpIntent = new Intent(context, WidgetTapNoOpReceiver.class)
                .setAction(WidgetTapNoOpReceiver.ACTION_NO_OP)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        PendingIntent noOpTap = PendingIntent.getBroadcast(context, appWidgetId,
                noOpIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        int[] inertViewIds = {
                R.id.widget_root, R.id.wallpaper_blur, R.id.widget_content, R.id.widget_clock,
                R.id.weather_area, R.id.weather_icon, R.id.weather_temp,
                R.id.weather_summary, R.id.solar_date, R.id.lunar_date,
                R.id.week_row, R.id.cell_0, R.id.cell_1, R.id.cell_2,
                R.id.cell_3, R.id.cell_4, R.id.cell_5, R.id.cell_6,
                R.id.weekday_0, R.id.weekday_1, R.id.weekday_2, R.id.weekday_3,
                R.id.weekday_4, R.id.weekday_5, R.id.weekday_6,
                R.id.daynum_0, R.id.daynum_1, R.id.daynum_2, R.id.daynum_3,
                R.id.daynum_4, R.id.daynum_5, R.id.daynum_6,
                R.id.lunar_daynum_0, R.id.lunar_daynum_1, R.id.lunar_daynum_2,
                R.id.lunar_daynum_3, R.id.lunar_daynum_4, R.id.lunar_daynum_5,
                R.id.lunar_daynum_6
        };
        for (int viewId : inertViewIds) {
            views.setOnClickPendingIntent(viewId, noOpTap);
        }

        manager.updateAppWidget(appWidgetId, views);
    }


    private static void applyResponsiveSizing(Context context, RemoteViews views, int widthDp, int heightDp) {
        float scaleW = Math.max(0.82f, Math.min(1.30f, widthDp / 300f));
        float scaleH = Math.max(0.88f, Math.min(1.25f, heightDp / 150f));
        // Width is the limiting factor for the seven-column calendar. Do not
        // let a launcher's conservative height estimate make every label tiny.
        float scale = Math.max(0.88f, Math.min(1.25f, Math.min(scaleW, scaleH)));
        views.setTextViewTextSize(R.id.widget_clock, 0, 40f * scale);
        views.setTextViewTextSize(R.id.weather_temp, 0, 21f * scale);
        views.setTextViewTextSize(R.id.solar_date, 0, Math.max(9f, 10f * scale));
        views.setTextViewTextSize(R.id.weather_summary, 0, Math.max(8f, 9f * scale));
        float daySize = Math.max(10f, 12f * scale);
        float weekdaySize = Math.max(8f, 9f * scale);
        float lunarSize = Math.max(7f, 7f * scale);
        for (int i = 0; i < 7; i++) {
            views.setTextViewTextSize(resourceId(views, i, 0), 0, weekdaySize);
            views.setTextViewTextSize(resourceId(views, i, 1), 0, daySize);
            views.setTextViewTextSize(resourceId(views, i, 2), 0, lunarSize);
        }
        int horizontalPadding = widthDp < 190 ? 5 : (widthDp < 250 ? 7 : 10);
        int verticalPadding = heightDp < 130 ? 4 : 6;
        views.setViewPadding(R.id.widget_content, horizontalPadding, verticalPadding,
                horizontalPadding, verticalPadding);
        int iconSize = Math.max(26, Math.min(44, Math.round(44f * scale)));
        int iconPx = Math.round(iconSize * context.getResources().getDisplayMetrics().density);
        views.setViewLayoutWidth(R.id.weather_icon, (float) iconPx, TypedValue.COMPLEX_UNIT_PX);
        views.setViewLayoutHeight(R.id.weather_icon, (float) iconPx, TypedValue.COMPLEX_UNIT_PX);
    }

    // IDs are resolved from the same stable resource naming used by the week renderer.
    private static int resourceId(RemoteViews ignored, int dayIndex, int field) {
        // The IDs are generated at compile time and passed through the dedicated arrays.
        if (field == 0) return DAY_WEEKDAY_IDS[dayIndex];
        if (field == 1) return DAY_NUMBER_IDS[dayIndex];
        return LUNAR_NUMBER_IDS[dayIndex];
    }

    private static final int[] DAY_WEEKDAY_IDS = {R.id.weekday_0, R.id.weekday_1, R.id.weekday_2,
            R.id.weekday_3, R.id.weekday_4, R.id.weekday_5, R.id.weekday_6};
    private static final int[] DAY_NUMBER_IDS = {R.id.daynum_0, R.id.daynum_1, R.id.daynum_2,
            R.id.daynum_3, R.id.daynum_4, R.id.daynum_5, R.id.daynum_6};
    private static final int[] LUNAR_NUMBER_IDS = {R.id.lunar_daynum_0, R.id.lunar_daynum_1,
            R.id.lunar_daynum_2, R.id.lunar_daynum_3, R.id.lunar_daynum_4,
            R.id.lunar_daynum_5, R.id.lunar_daynum_6};

}
