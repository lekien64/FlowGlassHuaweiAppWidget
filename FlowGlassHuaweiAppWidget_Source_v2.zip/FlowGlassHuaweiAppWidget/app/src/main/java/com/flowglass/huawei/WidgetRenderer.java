package com.flowglass.huawei;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.RemoteViews;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;

final class WidgetRenderer {
    private static final ZoneId VIETNAM_ZONE = ZoneId.of("Asia/Ho_Chi_Minh");
    private static final String[] WEEK_LABELS = {"T2", "T3", "T4", "T5", "T6", "T7", "CN"};
    private WidgetRenderer() {}

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, FlowGlassWidgetProvider.class));
        for (int id : ids) updateOne(context, manager, id);
    }

    static void updateOne(Context context, AppWidgetManager manager, int appWidgetId) {
        Bundle options = manager.getAppWidgetOptions(appWidgetId);
        int width = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH,
                options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250));
        boolean wide = width >= 340;
        RemoteViews views = new RemoteViews(context.getPackageName(),
                wide ? R.layout.widget_flow_glass_wide : R.layout.widget_flow_glass);

        LocalDate today = LocalDate.now(VIETNAM_ZONE);
        VietnameseLunarCalendar.LunarDate lunar = VietnameseLunarCalendar.fromSolar(today);
        String weekday = today.getDayOfWeek() == DayOfWeek.SUNDAY
                ? "CN" : "Thứ " + today.getDayOfWeek().getValue();
        String lunarSuffix = lunar.leapMonth ? " nhuận" : "";
        String combinedDate = weekday + ", " + today.getDayOfMonth() + "/" + today.getMonthValue()
                + " - Âl: " + lunar.day + "/" + lunar.month + lunarSuffix;
        views.setTextViewText(R.id.solar_date, combinedDate);
        views.setViewVisibility(R.id.lunar_date, android.view.View.GONE);

        LocalDate monday = today.with(DayOfWeek.MONDAY);
        for (int i = 0; i < 7; i++) {
            LocalDate date = monday.plusDays(i);
            VietnameseLunarCalendar.LunarDate lunarDay = VietnameseLunarCalendar.fromSolar(date);
            int weekdayId = context.getResources().getIdentifier("weekday_" + i, "id", context.getPackageName());
            int dayId = context.getResources().getIdentifier("daynum_" + i, "id", context.getPackageName());
            int lunarDayId = context.getResources().getIdentifier("lunar_daynum_" + i, "id", context.getPackageName());
            int cellId = context.getResources().getIdentifier("cell_" + i, "id", context.getPackageName());
            views.setTextViewText(weekdayId, WEEK_LABELS[i]);
            views.setTextViewText(dayId, String.valueOf(date.getDayOfMonth()));
            views.setTextViewText(lunarDayId, String.valueOf(lunarDay.day));
            boolean isToday = date.equals(today);
            views.setInt(cellId, "setBackgroundResource",
                    isToday ? R.drawable.day_today : R.drawable.day_normal);
            views.setTextColor(dayId, isToday ? Color.rgb(255, 177, 91) : Color.WHITE);
        }

        WeatherRepository.Weather weather = WeatherRepository.read(context);
        views.setTextViewText(R.id.weather_temp, weather.temperature);
        String details = weather.summary;
        if (!weather.range.isEmpty()) details += " · " + weather.range;
        views.setTextViewText(R.id.weather_summary, details);
        // Static weather symbol: no looping weather animation.
        views.setImageViewResource(R.id.weather_icon, WeatherRepository.iconResource(weather));
        WallpaperGlassRenderer.apply(context, views);

        // All widget touch zones are intentionally inert. Clear any click handlers
        // retained by the launcher from an older installed build.
        int[] inertViewIds = {
                R.id.widget_root, R.id.widget_content, R.id.widget_clock,
                R.id.weather_area, R.id.weather_icon, R.id.weather_temp,
                R.id.weather_summary, R.id.solar_date, R.id.lunar_date,
                R.id.week_row, R.id.cell_0, R.id.cell_1, R.id.cell_2,
                R.id.cell_3, R.id.cell_4, R.id.cell_5, R.id.cell_6
        };
        for (int viewId : inertViewIds) {
            views.setOnClickPendingIntent(viewId, null);
        }

        manager.updateAppWidget(appWidgetId, views);
    }

}
