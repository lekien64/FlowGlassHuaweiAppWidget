package com.flowglass.huawei;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Explicit no-op target used to override stale widget click intents from older builds. */
public final class WidgetTapNoOpReceiver extends BroadcastReceiver {
    public static final String ACTION_NO_OP = "com.flowglass.huawei.ACTION_WIDGET_TAP_NO_OP";

    @Override public void onReceive(Context context, Intent intent) {
        // Intentionally empty: tapping the widget must not launch any application.
    }
}
