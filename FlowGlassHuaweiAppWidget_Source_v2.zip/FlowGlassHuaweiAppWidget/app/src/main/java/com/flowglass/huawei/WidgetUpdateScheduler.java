package com.flowglass.huawei;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;

final class WidgetUpdateScheduler {
    private WidgetUpdateScheduler() {}
    static void schedule(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;
        Intent intent = new Intent(context, FlowGlassWidgetProvider.class);
        intent.setAction(FlowGlassWidgetProvider.ACTION_REFRESH);
        PendingIntent pending = PendingIntent.getBroadcast(context, 731, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        long interval = 3L * 60L * 60L * 1000L;
        alarm.setInexactRepeating(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 60000L,
                interval, pending);
    }
}
