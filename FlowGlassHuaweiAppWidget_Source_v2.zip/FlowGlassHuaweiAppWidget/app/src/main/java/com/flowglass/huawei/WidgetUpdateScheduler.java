package com.flowglass.huawei;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;

import java.time.ZonedDateTime;
import java.time.ZoneId;

final class WidgetUpdateScheduler {
    private static final ZoneId VIETNAM_ZONE = ZoneId.of("Asia/Ho_Chi_Minh");
    private static final int WEATHER_REQUEST_CODE = 731;
    private static final int DAILY_DATE_REQUEST_CODE = 732;

    private WidgetUpdateScheduler() {}

    static void schedule(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;

        // Weather refresh: keep the existing lightweight 3-hour interval.
        Intent weatherIntent = new Intent(context, FlowGlassWidgetProvider.class);
        weatherIntent.setAction(FlowGlassWidgetProvider.ACTION_REFRESH);
        PendingIntent weatherPending = PendingIntent.getBroadcast(context, WEATHER_REQUEST_CODE,
                weatherIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        long interval = 3L * 60L * 60L * 1000L;
        alarm.setInexactRepeating(AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + 60000L, interval, weatherPending);

        // Calendar refresh is independent from weather/network. Schedule shortly
        // after midnight in Vietnam time so weekday, solar date and lunar date roll over.
        scheduleNextDailyDateRefresh(context, alarm);
    }

    static void scheduleNextDailyDateRefresh(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;
        scheduleNextDailyDateRefresh(context, alarm);
    }

    private static void scheduleNextDailyDateRefresh(Context context, AlarmManager alarm) {
        ZonedDateTime now = ZonedDateTime.now(VIETNAM_ZONE);
        ZonedDateTime next = now.toLocalDate().plusDays(1).atTime(0, 5).atZone(VIETNAM_ZONE);
        long triggerAtMillis = next.toInstant().toEpochMilli();

        Intent intent = new Intent(context, FlowGlassWidgetProvider.class);
        intent.setAction(FlowGlassWidgetProvider.ACTION_DAILY_DATE_REFRESH);
        PendingIntent pending = PendingIntent.getBroadcast(context, DAILY_DATE_REQUEST_CODE,
                intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pending);
    }
}
