package com.flowglass.huawei;
import java.time.LocalDate;
public class LunarCalendarSmokeTest {
    public static void main(String[] args) {
        check(LocalDate.of(2024, 2, 10), 1, 1, 2024);
        check(LocalDate.of(2024, 9, 17), 15, 8, 2024);
        check(LocalDate.of(2025, 1, 29), 1, 1, 2025);
        check(LocalDate.of(2025, 2, 12), 15, 1, 2025);
        checkLeap(LocalDate.of(2023, 3, 22), 1, 2, 2023);
        checkLeap(LocalDate.of(2020, 5, 23), 1, 4, 2020);
        check(LocalDate.of(2026, 11, 5), 27, 9, 2026);
        check(LocalDate.of(2026, 11, 6), 28, 9, 2026);
        System.out.println("Lunar conversion smoke tests passed (UTC+7).");
    }
    private static void checkLeap(LocalDate date, int d, int m, int y) {
        VietnameseLunarCalendar.LunarDate actual = VietnameseLunarCalendar.fromSolar(date);
        if (actual.day != d || actual.month != m || actual.year != y || !actual.leapMonth) {
            throw new AssertionError(date + " expected leap " + d + "/" + m + "/" + y + " got " + actual + " leap=" + actual.leapMonth);
        }
    }
    private static void check(LocalDate date, int d, int m, int y) {
        VietnameseLunarCalendar.LunarDate actual = VietnameseLunarCalendar.fromSolar(date);
        if (actual.day != d || actual.month != m || actual.year != y) {
            throw new AssertionError(date + " expected " + d + "/" + m + "/" + y + " got " + actual);
        }
    }
}
