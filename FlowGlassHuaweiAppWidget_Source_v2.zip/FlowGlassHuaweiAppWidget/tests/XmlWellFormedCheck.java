import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import javax.xml.parsers.DocumentBuilderFactory;
public class XmlWellFormedCheck {
  public static void main(String[] args) throws Exception {
    Path root = Path.of(args[0]);
    int count = 0;
    var factory = DocumentBuilderFactory.newInstance();
    factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
    try (var paths = Files.walk(root)) {
      for (Path p : (Iterable<Path>) paths.filter(x -> x.toString().endsWith(".xml"))::iterator) {
        factory.newDocumentBuilder().parse(p.toFile());
        count++;
      }
    }
    System.out.println("XML well-formed files: " + count);
  }
}
